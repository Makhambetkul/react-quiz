import {useState, useEffect} from "react";
import Quiz from "./components/Quiz";
import './App.css';

export default function App() {
  const [questions, setQuestions]=useState([]);
  const [loading, setLoading]=useState(true);
  const [quizStarted, setQuizStarted]=useState(false);

  useEffect(()=>{
    const url=new URL("./data/questions.json", import.meta.url);

    fetch(url)
      .then((res)=> res.json())
      .then((data)=> setQuestions(data))
      .catch((err)=> console.error("Failed to load:", err))
      .finally(()=> setLoading(false));
  }, []);

  if (loading) return <p className="loading">Loading questions...</p>;

  return(
    <div>
    <h1 className="title"><span className="amazing">Amazing</span><span className="world"> world</span> of <span className="gumball">Gumball</span> Quiz</h1>

    {!quizStarted ? (
      <button onClick={()=> setQuizStarted(true)} className="start">Start Quiz</button>
    ) : (
      <Quiz questions={questions} />
    )}
    </div>
  );
}