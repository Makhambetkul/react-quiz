import { useState } from "react";

export default function QuizSelector({ quizzes, onSelect }) {
  const [query, setQuery] = useState("");

  const filtered = quizzes.filter(q =>
    q.title.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="quiz-selector">
      <input
        type="text"
        placeholder="Search quiz..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      <ul>
        {filtered.map((quiz) => (
          <li key={quiz.id}>
            <button onClick={() => onSelect(quiz)}>{quiz.title}</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
