import '../styles/QuestionCard.css';

export default function QuestionCard({
    question,
    options,
    selected,
    isCorrect,
    correctAnswer,
    onSelect
}) {
    return (
        <div className="question-card">
            <h2>{question}</h2>

            <div className="option-list">
                {options.map((opt) => {
                    const isChosen=selected === opt;

                    let className = "option-button";
                    if(selected){
                        if (opt === correctAnswer){
                            className += "-correct";
                        }
                        else if (isChosen && !isCorrect){
                            className += "-wrong";
                        }
                    }

                    return(
                        <button
                            key={opt}
                            onClick={()=> onSelect(opt)}
                            disabled={!!selected}
                            className={className}>
                                {opt}
                            </button>
                    );
                })}


            </div>

            {isCorrect === true && <p className="feedback">Correct</p>}
            {isCorrect === false && (
                <p className="feedback">Wrong. Correct answer: <strong>{correctAnswer}</strong></p>
            )}
        </div>
    )
}