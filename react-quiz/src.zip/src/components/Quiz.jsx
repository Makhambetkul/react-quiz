import {useState} from "react";
import QuestionCard from "./QuestionCard.jsx";
import Result from "./Result";
import '../styles/Quiz.css';


export default function Quiz({questions}){
    const [index, setIndex]=useState(0);
    const [selected, setSelected]=useState(null);
    const [isCorrect, setIsCorrect]=useState(null);
    const [score, setScore]=useState(0);

    const finished=index>=questions.length;
    const current=questions[index];

    function handleSelect(option){
        if(selected!==null) return;
        setSelected(option);

        const correct=option === current.answer;
        setIsCorrect(correct);
        if(correct) setScore((s)=> s+1);
    }

    function handleNext() {
        setIndex((i)=> i+1);
        setSelected(null);
        setIsCorrect(null);
    }

    function handleRestart(){
        setIndex(0);
        setScore(0);
        setSelected(null);
        setIsCorrect(null);
    }

    if (finished){
        return <Result score={score} total={questions.length} onRestart={handleRestart}/>;

    }

    return(
        <div>
            <p className="question">Question {index+1} / {questions.length}</p>

            <QuestionCard
                question={current.question}
                options={current.options}
                selected={selected}
                isCorrect={isCorrect}
                correctAnswer={current.answer}
                onSelect={handleSelect}
            />

            {selected && <button onClick={handleNext} className="next">Next</button>}
        </div>
    );
}