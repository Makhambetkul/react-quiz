import { useState } from "react";

export default function Review({ questions, onRestart }) {
  const [query, setQuery] = useState("");

  const filtered = questions.filter(q =>
    q.question.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="review">
      <h2>Review Answers</h2>
      <input
        type="text"
        placeholder="Search questions..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      <ul>
        {filtered.map((q, i) => (
          <li key={i}>
            <p><strong>{q.question}</strong></p>
            <p>✅ Correct answer: {q.answer}</p>
          </li>
        ))}
      </ul>

      <button onClick={onRestart}>Restart</button>
    </div>
  );
}
